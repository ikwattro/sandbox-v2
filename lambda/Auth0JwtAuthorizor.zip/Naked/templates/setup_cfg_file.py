#!/usr/bin/env python
# encoding: utf-8

# VARS: --none--
setup_cfg_string = """
[wheel]
universal = 1
"""
